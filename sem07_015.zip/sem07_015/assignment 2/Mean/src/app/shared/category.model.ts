export class Category {
    _id:string;
    CategoryNo:number;
    Category:string;
}
