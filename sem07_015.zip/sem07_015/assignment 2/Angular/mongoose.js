var express = require('express');
var app = express();

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/examtest',{useNewUrlParser:true});

var cors = require('cors');
app.use(cors());

var db = mongoose.connection;

db.on('open',function(req,res){
    console.log('connection successfully!!');
});

var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}))
var BookSchema = mongoose.Schema({
    code:Number,
    name:String,
    price:Number,
    gender:String,
    city:String
});

var Book = mongoose.model("Book",BookSchema);

app.get("/",function(req,res){
    Book.find(function(err,bk){
        res.send(bk);
    });
})

app.post("/insert",function(req,res){
    var b = new Book({
	code:req.body.code,
	name:req.body.name,
    price:req.body.price,
    gender:req.body.gender,
    city:req.body.city
	});
	
	console.log(b);

    b.save(function(err,bk){
        res.send(bk);
    });
});

app.delete("/delete/:id",function(req,res){
    Book.deleteOne({code:req.params.id},function(err,bk){
        if(err)
        console.error(err);

        res.send(bk);
    });
});

app.get("/getdata/:id",function(req,res){
    Book.findOne({code:req.params.id},function(err,bk){
        if(err)
        return console.error(err);
        res.send(bk);
    });
});

app.put("/edit/:id",function(req,res){
    Book.updateOne({code:req.params.id},
        {
            name:req.body.name,
            price:req.body.price,
            gender:req.body.gender,
            city:req.body.city
        },
        function(err,bk){
            if(err)
            console.error(err);
            res.send(bk);
        });
});

app.listen(8000);

